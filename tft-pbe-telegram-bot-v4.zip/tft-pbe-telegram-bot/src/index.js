require('dotenv').config();

const dns = require('dns');
dns.setDefaultResultOrder('ipv4first');

const fs = require('fs');
const path = require('path');
const { Telegraf, Markup } = require('telegraf');

const BOT_TOKEN = process.env.BOT_TOKEN;
const SETUP_KEY = process.env.SETUP_KEY || 'change-me-now';
const ADMIN_URL = process.env.ADMIN_URL || 'https://t.me/chuthedo';
const SUPPORT_URL = process.env.SUPPORT_URL || 'https://t.me/dionus_ctv';

if (!BOT_TOKEN) {
  console.error('Thiếu BOT_TOKEN trong file .env');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

const DATA_DIR = path.join(__dirname, '..', 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const COMMANDS_FILE = path.join(DATA_DIR, 'commands.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

const sessions = new Map();
const trackedMessages = new Map();

const DEFAULT_COMMANDS = [
  {
    id: 'login_error',
    title: 'Lỗi Không Đăng Nhập Được 🚫',
    text: `🚫 <b>LỖI KHÔNG ĐĂNG NHẬP ĐƯỢC</b>

1️⃣ Mở <b>Kiwi VPN</b>, chọn Singapore và đợi khoảng 1–2 phút.

2️⃣ Mở trình duyệt, truy cập link tạo tài khoản PBE rồi tải lại trang 1–2 lần.

3️⃣ Tạo tài khoản PBE như bình thường.

4️⃣ Tạo xong thì tắt VPN, mở game và đăng nhập.

🎬 Video hướng dẫn:
https://www.veed.io/view/b6fadbf9-ff54-429e-b398-55e678d0552d?panel=share`,
    media: [],
    system: true
  },
  {
    id: 'resource_error',
    title: 'Lỗi Tải Tài Nguyên 🚫',
    text: `🚫 <b>LỖI TẢI TÀI NGUYÊN</b>

Lỗi này thường xảy ra do thiết bị chưa sử dụng <b>iOS 26</b>.

Vui lòng liên hệ Admin hoặc Support để được hỗ trợ.`,
    media: [],
    system: true,
    contactButtons: true
  },
  {
    id: 'install_guide',
    title: 'Hướng Dẫn Cài Đặt 📖',
    text: `📖 <b>HƯỚNG DẪN CÀI ĐẶT</b>

<b>Bước 1:</b> Tải file <code>khoindvn.mobileconfig</code>.

<b>Bước 2:</b> Mở Cài đặt → Đã tải về hồ sơ → Cài đặt.

<b>Bước 3:</b> Cài game bằng link được cung cấp. Nếu báo “Ứng dụng không toàn vẹn”, xoá ứng dụng và thử link khác.

🔗 File bắt buộc:
https://github.com/dns-khoindvn/oci-auto-vm/releases/download/DNS/khoindvn.mobileconfig

🎬 Video:
https://www.veed.io/view/0f715a32-3164-46f1-b7ec-b2b82f38d4e1?source=Dashboard&panel=share`,
    media: [],
    system: true
  },
  {
    id: 'trusted_developer',
    title: 'Lỗi Nhà Phát Triển Không Được Tin Cậy 🚫',
    text: `🚫 <b>NHÀ PHÁT TRIỂN KHÔNG ĐƯỢC TIN CẬY</b>

Mở Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị → chọn chứng chỉ ứng dụng → Tin cậy → xác nhận Tin cậy.`,
    media: [],
    system: true
  },
  {
    id: 'vip_price',
    title: 'Bảng Giá Box Vip + Link Không Giới Hạn 💵',
    text: `💵 <b>BẢNG GIÁ BOX VIP UPDATE</b>

🔥 <b>50.000đ / 1 slot</b>

• Box VIP Update
• Link tải không giới hạn
• Cập nhật hoả tốc`,
    media: [],
    system: true,
    contactButtons: true
  }
];

function ensureData() {
  fs.mkdirSync(DATA_DIR, { recursive: true });

  if (!fs.existsSync(CONFIG_FILE)) {
    writeJson(CONFIG_FILE, { setupCompleted: false, adminIds: [] });
  }

  if (!fs.existsSync(COMMANDS_FILE)) {
    writeJson(COMMANDS_FILE, DEFAULT_COMMANDS);
  } else {
    const current = readJson(COMMANDS_FILE, []);
    if (!Array.isArray(current) || current.length === 0) {
      writeJson(COMMANDS_FILE, DEFAULT_COMMANDS);
    } else {
      let changed = false;
      for (const item of DEFAULT_COMMANDS) {
        if (!current.some(command => command.id === item.id)) {
          current.unshift(item);
          changed = true;
        }
      }
      if (changed) writeJson(COMMANDS_FILE, current);
    }
  }

  if (!fs.existsSync(USERS_FILE)) {
    writeJson(USERS_FILE, []);
  }
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error(`Không đọc được ${file}:`, error.message);
    return fallback;
  }
}

function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}

function getConfig() {
  ensureData();
  return readJson(CONFIG_FILE, { setupCompleted: false, adminIds: [] });
}

function getCommands() {
  ensureData();
  const data = readJson(COMMANDS_FILE, DEFAULT_COMMANDS);
  return Array.isArray(data) ? data : DEFAULT_COMMANDS;
}

function saveCommands(commands) {
  writeJson(COMMANDS_FILE, commands);
}

function getUsers() {
  ensureData();
  const data = readJson(USERS_FILE, []);
  return Array.isArray(data) ? data : [];
}

function registerUser(ctx) {
  const chatId = Number(ctx.chat?.id);
  if (!chatId || ctx.chat?.type !== 'private') return;

  const users = getUsers();
  const index = users.findIndex(user => Number(user.chatId) === chatId);
  const record = {
    chatId,
    userId: Number(ctx.from?.id),
    username: ctx.from?.username || '',
    firstName: ctx.from?.first_name || '',
    lastName: ctx.from?.last_name || '',
    updatedAt: new Date().toISOString()
  };

  if (index >= 0) users[index] = { ...users[index], ...record };
  else users.push({ ...record, createdAt: new Date().toISOString() });

  writeJson(USERS_FILE, users);
}

function isSetup() {
  return getConfig().setupCompleted === true;
}

function isAdmin(ctx) {
  return getConfig().adminIds.includes(Number(ctx.from?.id));
}

function remember(chatId, messageId) {
  if (!chatId || !messageId) return;
  if (!trackedMessages.has(chatId)) trackedMessages.set(chatId, new Set());
  trackedMessages.get(chatId).add(messageId);
}

function rememberIncoming(ctx) {
  registerUser(ctx);
  remember(ctx.chat?.id, ctx.message?.message_id);
}

async function sendTracked(ctx, method, ...args) {
  const result = await ctx[method](...args);
  remember(ctx.chat.id, result.message_id);
  return result;
}

async function clearTracked(ctx) {
  const chatId = ctx.chat?.id;
  if (!chatId) return;

  const ids = new Set(trackedMessages.get(chatId) || []);
  if (ctx.callbackQuery?.message?.message_id) ids.add(ctx.callbackQuery.message.message_id);
  if (ctx.message?.message_id) ids.add(ctx.message.message_id);

  for (const messageId of [...ids].sort((a, b) => b - a)) {
    try {
      await ctx.telegram.deleteMessage(chatId, messageId);
    } catch (_) {}
  }

  trackedMessages.set(chatId, new Set());
}

async function answerCallback(ctx) {
  registerUser(ctx);
  try {
    await ctx.answerCbQuery();
  } catch (_) {}
}

function backButton() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Quay lại menu', 'main_menu')]
  ]);
}

function contactButtons() {
  return Markup.inlineKeyboard([
    [
      Markup.button.url('👨‍💻 Support', SUPPORT_URL),
      Markup.button.url('🛡 Admin', ADMIN_URL)
    ],
    [Markup.button.callback('⬅️ Quay lại menu', 'main_menu')]
  ]);
}

function mainMenu() {
  const rows = getCommands().map(command => [
    Markup.button.callback(command.title, `command:${command.id}`)
  ]);

  rows.push([Markup.button.callback('Liên Hệ Admin Hoặc Support 💬', 'contact')]);
  return Markup.inlineKeyboard(rows);
}

function adminMenu() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('➕ Tạo lệnh mới', 'admin_create')],
    [Markup.button.callback('✏️ Chỉnh sửa lệnh', 'admin_edit')],
    [Markup.button.callback('📋 Danh sách lệnh', 'admin_list')],
    [Markup.button.callback('🗑 Xoá lệnh', 'admin_delete')],
    [Markup.button.callback('🏠 Về menu người dùng', 'main_menu')]
  ]);
}

function editMenu(commandId) {
  return Markup.inlineKeyboard([
    [Markup.button.callback('✏️ Sửa tên nút', `edit_title:${commandId}`)],
    [Markup.button.callback('📝 Sửa nội dung', `edit_text:${commandId}`)],
    [Markup.button.callback('🖼 Thay ảnh/video', `edit_media:${commandId}`)],
    [Markup.button.callback('🧹 Xoá toàn bộ media', `clear_media:${commandId}`)],
    [Markup.button.callback('⬅️ Quay lại quản trị', 'admin_back')]
  ]);
}

const welcomeText =
  '🌸 <b>Xin chào! Mình là Bot của TFT PBE Community VN.</b>\n\n' +
  'Bạn đang cần hỗ trợ vấn đề nào? Hãy chọn một mục bên dưới.';

async function showSetupRequired(ctx) {
  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    '⚠️ Bot chưa được thiết lập.\n\nAdmin dùng:\n<code>/setup MÃ_SETUP</code>',
    { parse_mode: 'HTML' }
  );
}

async function showMainMenu(ctx) {
  if (!isSetup()) {
    await showSetupRequired(ctx);
    return;
  }

  await clearTracked(ctx);
  await sendTracked(ctx, 'reply', welcomeText, {
    parse_mode: 'HTML',
    ...mainMenu()
  });
}

async function sendText(ctx, text, keyboard = backButton()) {
  const chunks = [];
  let remaining = text || '';

  while (remaining.length > 3900) {
    let cut = remaining.lastIndexOf('\n', 3900);
    if (cut < 1000) cut = 3900;
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut).trimStart();
  }
  chunks.push(remaining);

  for (let i = 0; i < chunks.length; i += 1) {
    await sendTracked(ctx, 'reply', chunks[i], {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...(i === chunks.length - 1 ? keyboard : {})
    });
  }
}

async function sendMedia(ctx, mediaItems) {
  for (const item of mediaItems || []) {
    try {
      const options = { caption: item.caption || undefined };
      if (item.type === 'photo') {
        await sendTracked(ctx, 'replyWithPhoto', item.fileId, options);
      } else if (item.type === 'video') {
        await sendTracked(ctx, 'replyWithVideo', item.fileId, {
          ...options,
          supports_streaming: true
        });
      } else if (item.type === 'animation') {
        await sendTracked(ctx, 'replyWithAnimation', item.fileId, options);
      } else if (item.type === 'document') {
        await sendTracked(ctx, 'replyWithDocument', item.fileId, options);
      }
    } catch (error) {
      console.error('Không gửi được media:', error.message);
    }
  }
}

function extractMedia(message) {
  const caption = message.caption || '';

  if (message.photo?.length) {
    return {
      type: 'photo',
      fileId: message.photo[message.photo.length - 1].file_id,
      caption
    };
  }

  if (message.video) {
    return { type: 'video', fileId: message.video.file_id, caption };
  }

  if (message.animation) {
    return { type: 'animation', fileId: message.animation.file_id, caption };
  }

  if (message.document) {
    return { type: 'document', fileId: message.document.file_id, caption };
  }

  return null;
}

async function broadcastText(ctx, content) {
  const users = getUsers();
  let success = 0;
  let failed = 0;
  const inactive = [];

  await ctx.reply(`📢 Bắt đầu gửi thông báo tới ${users.length} người dùng...`);

  for (const user of users) {
    try {
      await ctx.telegram.sendMessage(user.chatId, content, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
      });
      success += 1;
    } catch (error) {
      failed += 1;
      if ([403, 400].includes(error.response?.error_code)) {
        inactive.push(user.chatId);
      }
      console.error(`Broadcast lỗi ${user.chatId}:`, error.message);
    }

    await new Promise(resolve => setTimeout(resolve, 40));
  }

  if (inactive.length) {
    writeJson(
      USERS_FILE,
      users.filter(user => !inactive.includes(Number(user.chatId)))
    );
  }

  await ctx.reply(
    `✅ Gửi thông báo hoàn tất.\n\n` +
    `Thành công: ${success}\n` +
    `Thất bại: ${failed}\n` +
    `Đã loại khỏi danh sách: ${inactive.length}`
  );
}

bot.command('setup', async ctx => {
  rememberIncoming(ctx);

  const parts = ctx.message.text.trim().split(/\s+/);
  const suppliedKey = parts[1] || '';
  const config = getConfig();

  if (config.setupCompleted) {
    await clearTracked(ctx);
    await sendTracked(
      ctx,
      'reply',
      isAdmin(ctx)
        ? '✅ Bot đã được thiết lập. Dùng /admin để quản trị.'
        : '⛔ Bot đã có chủ sở hữu, không thể setup lại.',
      backButton()
    );
    return;
  }

  if (suppliedKey !== SETUP_KEY) {
    await clearTracked(ctx);
    await sendTracked(
      ctx,
      'reply',
      '❌ Mã setup không đúng.\n\nCú pháp: <code>/setup MÃ_SETUP</code>',
      { parse_mode: 'HTML' }
    );
    return;
  }

  config.setupCompleted = true;
  config.adminIds = [Number(ctx.from.id)];
  config.setupAt = new Date().toISOString();
  writeJson(CONFIG_FILE, config);

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    `✅ <b>SETUP THÀNH CÔNG</b>\n\nBạn đã trở thành Admin.\nTelegram ID: <code>${ctx.from.id}</code>\n\nDùng /admin để quản trị.`,
    { parse_mode: 'HTML', ...adminMenu() }
  );
});

bot.start(async ctx => {
  rememberIncoming(ctx);
  await showMainMenu(ctx);
});

bot.command('menu', async ctx => {
  rememberIncoming(ctx);
  await showMainMenu(ctx);
});

bot.command('admin', async ctx => {
  rememberIncoming(ctx);

  if (!isSetup()) {
    await showSetupRequired(ctx);
    return;
  }

  await clearTracked(ctx);

  if (!isAdmin(ctx)) {
    await sendTracked(ctx, 'reply', '⛔ Bạn không có quyền quản trị.', backButton());
    return;
  }

  sessions.delete(ctx.from.id);
  await sendTracked(ctx, 'reply', '⚙️ <b>QUẢN TRỊ BOT</b>', {
    parse_mode: 'HTML',
    ...adminMenu()
  });
});

bot.command('thongbao', async ctx => {
  rememberIncoming(ctx);

  if (!isAdmin(ctx)) {
    await ctx.reply('⛔ Bạn không có quyền gửi thông báo.');
    return;
  }

  const content = ctx.message.text.replace(/^\/thongbao(?:@\w+)?\s*/i, '').trim();

  if (!content) {
    await ctx.reply(
      'Cú pháp:\n<code>/thongbao Nội dung cần gửi</code>',
      { parse_mode: 'HTML' }
    );
    return;
  }

  await broadcastText(ctx, content);
});

bot.action('main_menu', async ctx => {
  await answerCallback(ctx);
  sessions.delete(ctx.from.id);
  await showMainMenu(ctx);
});

bot.action('contact', async ctx => {
  await answerCallback(ctx);
  await clearTracked(ctx);
  await sendTracked(ctx, 'reply', '💬 <b>LIÊN HỆ HỖ TRỢ</b>', {
    parse_mode: 'HTML',
    ...contactButtons()
  });
});

bot.action(/^command:(.+)$/, async ctx => {
  await answerCallback(ctx);
  const command = getCommands().find(item => item.id === ctx.match[1]);

  await clearTracked(ctx);

  if (!command) {
    await sendTracked(ctx, 'reply', 'Nội dung này không còn tồn tại.', backButton());
    return;
  }

  if (command.text) {
    await sendText(ctx, command.text, {});
  }

  await sendMedia(ctx, command.media);

  await sendTracked(
    ctx,
    'reply',
    '⬇️ Chọn thao tác tiếp theo:',
    command.contactButtons ? contactButtons() : backButton()
  );
});

bot.action('admin_create', async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  await clearTracked(ctx);
  sessions.set(ctx.from.id, {
    mode: 'create',
    step: 'title',
    draft: { title: '', text: '', media: [] }
  });

  await sendTracked(
    ctx,
    'reply',
    '➕ <b>TẠO LỆNH MỚI</b>\n\nGửi tên nút muốn hiển thị.',
    { parse_mode: 'HTML' }
  );
});

bot.action('admin_edit', async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  await clearTracked(ctx);
  const rows = getCommands().map(item => [
    Markup.button.callback(`✏️ ${item.title}`, `edit_select:${item.id}`)
  ]);
  rows.push([Markup.button.callback('⬅️ Quay lại', 'admin_back')]);

  await sendTracked(ctx, 'reply', 'Chọn lệnh cần chỉnh sửa:', Markup.inlineKeyboard(rows));
});

bot.action(/^edit_select:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  const command = getCommands().find(item => item.id === ctx.match[1]);
  await clearTracked(ctx);

  if (!command) {
    await sendTracked(ctx, 'reply', 'Lệnh không tồn tại.', adminMenu());
    return;
  }

  await sendTracked(
    ctx,
    'reply',
    `✏️ <b>CHỈNH SỬA LỆNH</b>\n\n<b>${command.title}</b>\nMedia: ${command.media?.length || 0} file`,
    { parse_mode: 'HTML', ...editMenu(command.id) }
  );
});

bot.action(/^edit_title:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  sessions.set(ctx.from.id, {
    mode: 'edit',
    step: 'edit_title',
    commandId: ctx.match[1]
  });

  await clearTracked(ctx);
  await sendTracked(ctx, 'reply', 'Gửi tên nút mới:');
});

bot.action(/^edit_text:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  sessions.set(ctx.from.id, {
    mode: 'edit',
    step: 'edit_text',
    commandId: ctx.match[1]
  });

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    'Gửi nội dung mới.\n\nGửi <code>/xoa_noidung</code> nếu muốn để trống nội dung chữ.',
    { parse_mode: 'HTML' }
  );
});

bot.action(/^edit_media:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  sessions.set(ctx.from.id, {
    mode: 'edit',
    step: 'edit_media',
    commandId: ctx.match[1],
    media: []
  });

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    '🖼 Gửi bộ ảnh/video mới.\n\nMedia cũ sẽ được thay thế khi gửi /done.\nCó thể gửi nhiều file.'
  );
});

bot.action(/^clear_media:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  const commands = getCommands();
  const command = commands.find(item => item.id === ctx.match[1]);

  if (command) {
    command.media = [];
    saveCommands(commands);
  }

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    command ? `✅ Đã xoá toàn bộ media của <b>${command.title}</b>.` : 'Lệnh không tồn tại.',
    { parse_mode: 'HTML', ...adminMenu() }
  );
});

bot.action('admin_list', async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  await clearTracked(ctx);
  const commands = getCommands();
  const text = commands.length
    ? commands.map((item, i) =>
        `${i + 1}. <b>${item.title}</b>\nMedia: ${item.media?.length || 0} file`
      ).join('\n\n')
    : 'Chưa có lệnh nào.';

  await sendTracked(ctx, 'reply', `📋 <b>DANH SÁCH LỆNH</b>\n\n${text}`, {
    parse_mode: 'HTML',
    ...adminMenu()
  });
});

bot.action('admin_delete', async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  await clearTracked(ctx);
  const commands = getCommands();

  const rows = commands.map(item => [
    Markup.button.callback(`🗑 ${item.title}`, `delete:${item.id}`)
  ]);
  rows.push([Markup.button.callback('⬅️ Quay lại', 'admin_back')]);

  await sendTracked(ctx, 'reply', 'Chọn lệnh cần xoá:', Markup.inlineKeyboard(rows));
});

bot.action(/^delete:(.+)$/, async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  const commands = getCommands();
  const target = commands.find(item => item.id === ctx.match[1]);
  saveCommands(commands.filter(item => item.id !== ctx.match[1]));

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    target ? `✅ Đã xoá: <b>${target.title}</b>` : 'Lệnh không còn tồn tại.',
    { parse_mode: 'HTML', ...adminMenu() }
  );
});

bot.action('admin_back', async ctx => {
  await answerCallback(ctx);
  if (!isAdmin(ctx)) return;

  sessions.delete(ctx.from.id);
  await clearTracked(ctx);
  await sendTracked(ctx, 'reply', '⚙️ <b>QUẢN TRỊ BOT</b>', {
    parse_mode: 'HTML',
    ...adminMenu()
  });
});

bot.command('skip', async ctx => {
  rememberIncoming(ctx);
  const session = sessions.get(ctx.from.id);
  if (!session || !isAdmin(ctx)) return;

  if (session.mode === 'create' && session.step === 'text') {
    session.draft.text = '';
    session.step = 'media';
    sessions.set(ctx.from.id, session);

    await sendTracked(
      ctx,
      'reply',
      '📎 Gửi ảnh/video muốn đính kèm.\nXong thì gửi /done.'
    );
  }
});

bot.command('xoa_noidung', async ctx => {
  rememberIncoming(ctx);
  const session = sessions.get(ctx.from.id);
  if (!session || !isAdmin(ctx) || session.step !== 'edit_text') return;

  const commands = getCommands();
  const command = commands.find(item => item.id === session.commandId);

  if (command) {
    command.text = '';
    saveCommands(commands);
  }

  sessions.delete(ctx.from.id);
  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    command ? `✅ Đã xoá nội dung chữ của <b>${command.title}</b>.` : 'Lệnh không tồn tại.',
    { parse_mode: 'HTML', ...adminMenu() }
  );
});

bot.command('done', async ctx => {
  rememberIncoming(ctx);
  const session = sessions.get(ctx.from.id);
  if (!session || !isAdmin(ctx)) return;

  if (session.mode === 'create' && session.step === 'media') {
    if (!session.draft.text && session.draft.media.length === 0) {
      await sendTracked(ctx, 'reply', 'Phải có ít nhất nội dung chữ, ảnh hoặc video.');
      return;
    }

    const commands = getCommands();
    commands.push({
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      title: session.draft.title,
      text: session.draft.text,
      media: session.draft.media,
      createdBy: Number(ctx.from.id),
      createdAt: new Date().toISOString()
    });
    saveCommands(commands);

    sessions.delete(ctx.from.id);
    await clearTracked(ctx);
    await sendTracked(
      ctx,
      'reply',
      `✅ Đã tạo lệnh <b>${session.draft.title}</b>.`,
      { parse_mode: 'HTML', ...adminMenu() }
    );
    return;
  }

  if (session.mode === 'edit' && session.step === 'edit_media') {
    const commands = getCommands();
    const command = commands.find(item => item.id === session.commandId);

    if (command) {
      command.media = session.media;
      saveCommands(commands);
    }

    sessions.delete(ctx.from.id);
    await clearTracked(ctx);
    await sendTracked(
      ctx,
      'reply',
      command
        ? `✅ Đã thay media của <b>${command.title}</b> bằng ${session.media.length} file.`
        : 'Lệnh không tồn tại.',
      { parse_mode: 'HTML', ...adminMenu() }
    );
  }
});

bot.on(['photo', 'video', 'animation', 'document'], async ctx => {
  rememberIncoming(ctx);

  const session = sessions.get(ctx.from.id);
  if (!session || !isAdmin(ctx)) return;

  const media = extractMedia(ctx.message);
  if (!media) return;

  if (session.mode === 'create' && session.step === 'media') {
    session.draft.media.push(media);
    sessions.set(ctx.from.id, session);
    await sendTracked(
      ctx,
      'reply',
      `✅ Đã thêm ${media.type}. Tổng: ${session.draft.media.length} file.\nGửi tiếp hoặc /done.`
    );
    return;
  }

  if (session.mode === 'edit' && session.step === 'edit_media') {
    session.media.push(media);
    sessions.set(ctx.from.id, session);
    await sendTracked(
      ctx,
      'reply',
      `✅ Đã thêm ${media.type}. Tổng media mới: ${session.media.length} file.\nGửi tiếp hoặc /done.`
    );
  }
});

bot.on('text', async ctx => {
  rememberIncoming(ctx);

  if (!isSetup()) {
    await showSetupRequired(ctx);
    return;
  }

  const session = sessions.get(ctx.from.id);

  if (session && isAdmin(ctx)) {
    const text = ctx.message.text.trim();

    if (session.mode === 'create' && session.step === 'title') {
      if (text.length < 2 || text.length > 60) {
        await sendTracked(ctx, 'reply', 'Tên nút phải từ 2 đến 60 ký tự.');
        return;
      }

      session.draft.title = text;
      session.step = 'text';
      sessions.set(ctx.from.id, session);

      await sendTracked(
        ctx,
        'reply',
        `✅ Tên nút: <b>${text}</b>\n\nGửi nội dung trả lời hoặc /skip.`,
        { parse_mode: 'HTML' }
      );
      return;
    }

    if (session.mode === 'create' && session.step === 'text') {
      session.draft.text = text;
      session.step = 'media';
      sessions.set(ctx.from.id, session);

      await sendTracked(
        ctx,
        'reply',
        '📎 Gửi ảnh/video muốn đính kèm.\nXong thì gửi /done.'
      );
      return;
    }

    if (session.mode === 'edit' && session.step === 'edit_title') {
      const commands = getCommands();
      const command = commands.find(item => item.id === session.commandId);

      if (command) {
        command.title = text.slice(0, 60);
        saveCommands(commands);
      }

      sessions.delete(ctx.from.id);
      await clearTracked(ctx);
      await sendTracked(
        ctx,
        'reply',
        command ? `✅ Đã đổi tên thành <b>${command.title}</b>.` : 'Lệnh không tồn tại.',
        { parse_mode: 'HTML', ...adminMenu() }
      );
      return;
    }

    if (session.mode === 'edit' && session.step === 'edit_text') {
      const commands = getCommands();
      const command = commands.find(item => item.id === session.commandId);

      if (command) {
        command.text = text;
        saveCommands(commands);
      }

      sessions.delete(ctx.from.id);
      await clearTracked(ctx);
      await sendTracked(
        ctx,
        'reply',
        command ? `✅ Đã cập nhật nội dung của <b>${command.title}</b>.` : 'Lệnh không tồn tại.',
        { parse_mode: 'HTML', ...adminMenu() }
      );
      return;
    }
  }

  await clearTracked(ctx);
  await sendTracked(
    ctx,
    'reply',
    'Mình chưa hiểu nội dung này. Vui lòng chọn một mục trong menu.',
    mainMenu()
  );
});

bot.catch((error, ctx) => {
  console.error(`Bot lỗi ở update ${ctx.update?.update_id}:`, error);
});

async function start() {
  ensureData();

  await bot.telegram.setMyCommands([
    { command: 'start', description: 'Khởi động bot' },
    { command: 'menu', description: 'Mở menu' },
    { command: 'setup', description: 'Thiết lập bot lần đầu' },
    { command: 'admin', description: 'Quản trị bot' },
    { command: 'thongbao', description: 'Gửi thông báo cho toàn bộ user' },
    { command: 'done', description: 'Hoàn tất tạo/chỉnh media' },
    { command: 'skip', description: 'Bỏ qua nội dung chữ' }
  ]);

  await bot.launch();
  console.log('Bot TFT PBE V4 đang chạy...');
}

start().catch(error => {
  console.error('Không khởi động được bot:', error);
  process.exit(1);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
