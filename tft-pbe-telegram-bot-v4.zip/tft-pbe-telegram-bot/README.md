# TFT PBE Telegram Bot V4

## Có gì mới

- Chỉnh sửa được toàn bộ lệnh, kể cả 5 lệnh mặc định ban đầu.
- Sửa tên nút, nội dung chữ, ảnh và video.
- Tạo lệnh mới kèm nhiều ảnh/video.
- Ghi nhớ toàn bộ người dùng đã nhắn bot.
- Admin dùng `/thongbao nội dung` để gửi cho toàn bộ người dùng.
- Tự loại những tài khoản đã chặn bot khỏi danh sách broadcast.

## Cài

```bash
npm install
cp .env.example .env
nano .env
```

Sau đó:

```bash
pm2 delete tft-pbe-bot
pm2 start src/index.js --name tft-pbe-bot
pm2 save
```

## Setup

```text
/setup MÃ_SETUP
```

## Chỉnh toàn bộ lệnh

```text
/admin
```

Chọn **Chỉnh sửa lệnh**, sau đó chọn bất kỳ lệnh nào, kể cả các lệnh mặc định.

## Thông báo toàn bộ user

```text
/thongbao Nội dung thông báo cần gửi
```

Danh sách user được lưu tại:

```text
data/users.json
```
