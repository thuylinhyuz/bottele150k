Đặt 5 ảnh hướng dẫn lỗi "Nhà phát triển không được tin cậy" vào thư mục này.

Tên file mặc định:
1.jpg
2.jpg
3.jpg
4.jpg
5.jpg

Bot sẽ tự gửi các ảnh tồn tại theo đúng thứ tự trên.
Có thể dùng định dạng .jpg, .jpeg hoặc .png, nhưng nên giữ tên 1.jpg đến 5.jpg.
