# TFT PBE Telegram Bot

Bot Telegram hỗ trợ người dùng TFT PBE, chạy bằng Node.js và thư viện Telegraf.

## 1. Yêu cầu

- Node.js 18 trở lên
- Token bot lấy từ @BotFather

## 2. Cài đặt

```bash
unzip tft-pbe-telegram-bot.zip
cd tft-pbe-telegram-bot
npm install
cp .env.example .env
nano .env
```

Điền `BOT_TOKEN` và các link tải vào file `.env`.

## 3. Thêm 5 ảnh hướng dẫn

Chép 5 ảnh vào:

```text
assets/trusted-developer/
```

Đặt tên:

```text
1.jpg
2.jpg
3.jpg
4.jpg
5.jpg
```

Bot sẽ gửi 5 ảnh khi người dùng chọn mục “Lỗi Nhà Phát Triển Không Được Tin Cậy”.

## 4. Chạy bot

```bash
npm start
```

Chạy nền bằng PM2:

```bash
npm install -g pm2
pm2 start src/index.js --name tft-pbe-bot
pm2 save
pm2 startup
```

## 5. Các nút có sẵn

- Lỗi không đăng nhập được
- Lỗi tải tài nguyên
- Hướng dẫn cài đặt
- Lỗi nhà phát triển không được tin cậy
- Bảng giá Box VIP
- Liên hệ Support/Admin

Hai nút liên hệ đang dùng:

- Admin: https://t.me/chuthedo
- Support: https://t.me/dionus_ctv
