require('dotenv').config();

const fs = require('fs');
const path = require('path');
const { Telegraf, Markup, Input } = require('telegraf');

const token = process.env.BOT_TOKEN;

if (!token) {
  console.error('Thiếu BOT_TOKEN trong file .env');
  process.exit(1);
}

const bot = new Telegraf(token);

const ADMIN_URL = process.env.ADMIN_URL || 'https://t.me/chuthedo';
const SUPPORT_URL = process.env.SUPPORT_URL || 'https://t.me/dionus_ctv';

const CALLBACK = {
  LOGIN_ERROR: 'login_error',
  RESOURCE_ERROR: 'resource_error',
  INSTALL_GUIDE: 'install_guide',
  TRUST_ERROR: 'trust_error',
  VIP_PRICE: 'vip_price',
  CONTACT: 'contact',
  MAIN_MENU: 'main_menu'
};

function mainMenu() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('Lỗi Không Đăng Nhập Được 🚫', CALLBACK.LOGIN_ERROR)],
    [Markup.button.callback('Lỗi Tải Tài Nguyên 🚫', CALLBACK.RESOURCE_ERROR)],
    [Markup.button.callback('Hướng Dẫn Cài Đặt 📖', CALLBACK.INSTALL_GUIDE)],
    [Markup.button.callback('Lỗi Nhà Phát Triển Không Được Tin Cậy 🚫', CALLBACK.TRUST_ERROR)],
    [Markup.button.callback('Bảng Giá Box Vip + Link Không Giới Hạn 💵', CALLBACK.VIP_PRICE)],
    [Markup.button.callback('Liên Hệ Admin Hoặc Support 💬', CALLBACK.CONTACT)]
  ]);
}

function backButton() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Quay lại menu', CALLBACK.MAIN_MENU)]
  ]);
}

function contactButtons() {
  return Markup.inlineKeyboard([
    [
      Markup.button.url('👨‍💻 Support', SUPPORT_URL),
      Markup.button.url('🛡 Admin', ADMIN_URL)
    ],
    [Markup.button.callback('⬅️ Quay lại menu', CALLBACK.MAIN_MENU)]
  ]);
}

const welcomeText =
  '🌸 <b>Xin chào! Mình là Bot của TFT PBE Community VN.</b>\n\n' +
  'Bạn đang cần hỗ trợ vấn đề nào? Hãy chọn một mục bên dưới.';

const loginErrorText = `
🚫 <b>LỖI KHÔNG ĐĂNG NHẬP ĐƯỢC</b>

1️⃣ Mở <b>Kiwi VPN</b> và chọn máy chủ <b>Singapore</b>, sau đó đợi khoảng 1–2 phút.

2️⃣ Mở trình duyệt, truy cập link tạo tài khoản PBE rồi tải lại trang 1–2 lần.

3️⃣ Tiến hành tạo tài khoản PBE như bình thường.

4️⃣ Sau khi tạo tài khoản thành công, tắt VPN rồi mở game và đăng nhập để chơi.

🎬 <b>Video hướng dẫn:</b>
https://www.veed.io/view/b6fadbf9-ff54-429e-b398-55e678d0552d?panel=share
`.trim();

const resourceErrorText = `
🚫 <b>LỖI TẢI TÀI NGUYÊN</b>

Lỗi này thường xảy ra do thiết bị của bạn chưa sử dụng <b>iOS 26</b>.

Vui lòng liên hệ Admin hoặc Support để được kiểm tra và hỗ trợ.
`.trim();

function getDownloadLinks() {
  const links = [];
  for (let i = 1; i <= 10; i += 1) {
    const value = (process.env[`DOWNLOAD_LINK_${i}`] || '').trim();
    links.push(`🔗 <b>Link ${i}:</b>${value ? `\n${value}` : ' Chưa cập nhật'}`);
  }
  return links.join('\n\n');
}

function installGuideText() {
  return `
📖 <b>HƯỚNG DẪN CÀI ĐẶT CHI TIẾT</b>

<b>Bước 1: Tải hồ sơ cấu hình</b>

• Truy cập tệp bắt buộc được cung cấp.
• Tìm file <code>khoindvn.mobileconfig</code>.
• Nhấn vào file để tải hồ sơ cấu hình về thiết bị.

<b>Bước 2: Cài đặt hồ sơ</b>

• Mở ứng dụng <b>Cài đặt (Settings)</b> trên iPhone.
• Ở phía trên màn hình, chọn <b>Đã tải về hồ sơ</b>.
• Nhấn <b>Cài đặt</b> và làm theo hướng dẫn.
• Nhập mật mã thiết bị nếu được yêu cầu.

<b>Bước 3: Tải ứng dụng</b>

• Sau khi cài hồ sơ thành công, tải ứng dụng bằng một trong các link bên dưới.
• Nếu xuất hiện lỗi <b>Ứng dụng không toàn vẹn</b>, hãy xoá ứng dụng vừa tải và thử lại bằng link khác.

📥 <b>LINK TẢI MIỄN PHÍ TFT PBE MÙA 18</b>

⚠️ Vui lòng cài file bắt buộc trước khi cài game.

🔗 <b>File bắt buộc khoindvn.mobileconfig:</b>
https://github.com/dns-khoindvn/oci-auto-vm/releases/download/DNS/khoindvn.mobileconfig

${getDownloadLinks()}

🎬 <b>Video hướng dẫn:</b>
https://www.veed.io/view/0f715a32-3164-46f1-b7ec-b2b82f38d4e1?source=Dashboard&panel=share
`.trim();
}

const trustedDeveloperText = `
🚫 <b>LỖI “NHÀ PHÁT TRIỂN KHÔNG ĐƯỢC TIN CẬY”</b>

Thực hiện lần lượt các bước sau:

1️⃣ Mở <b>Cài đặt (Settings)</b> trên iPhone.

2️⃣ Chọn <b>Cài đặt chung (General)</b>.

3️⃣ Chọn <b>VPN & Quản lý thiết bị (VPN & Device Management)</b>.

4️⃣ Trong mục <b>Ứng dụng doanh nghiệp</b> hoặc <b>Nhà phát triển</b>, tìm chứng chỉ của ứng dụng vừa cài đặt.

5️⃣ Nhấn vào tên chứng chỉ hoặc nhà phát triển.

6️⃣ Chọn <b>Tin cậy “[Tên nhà phát triển]”</b>.

7️⃣ Nhấn <b>Tin cậy</b> thêm một lần nữa để xác nhận.

Sau khi hoàn tất, quay lại màn hình chính và mở lại ứng dụng.
`.trim();

const vipPriceText = `
💵 <b>BẢNG GIÁ BOX VIP UPDATE + LINK TẢI KHÔNG GIỚI HẠN</b>

🔥 <b>50.000đ / 1 slot</b>

Quyền lợi:
• Vào Box VIP Update.
• Nhận link tải không giới hạn.
• Cập nhật hoả tốc khi có bản mới.
`.trim();

async function safeAnswerCbQuery(ctx) {
  try {
    await ctx.answerCbQuery();
  } catch (_) {
    // Callback có thể hết hạn, không cần làm bot dừng.
  }
}

async function showMainMenu(ctx, edit = false) {
  if (edit && ctx.callbackQuery?.message) {
    try {
      await ctx.editMessageText(welcomeText, {
        parse_mode: 'HTML',
        ...mainMenu()
      });
      return;
    } catch (_) {
      // Tin nhắn cũ không sửa được thì gửi tin mới.
    }
  }

  await ctx.reply(welcomeText, {
    parse_mode: 'HTML',
    ...mainMenu()
  });
}

async function sendTrustedDeveloperImages(ctx) {
  const directory = path.join(__dirname, '..', 'assets', 'trusted-developer');
  const extensions = ['jpg', 'jpeg', 'png', 'webp'];
  const files = [];

  for (let i = 1; i <= 5; i += 1) {
    const found = extensions
      .map(ext => path.join(directory, `${i}.${ext}`))
      .find(file => fs.existsSync(file));

    if (found) files.push(found);
  }

  if (files.length === 0) return;

  const media = files.map(file => ({
    type: 'photo',
    media: Input.fromLocalFile(file)
  }));

  try {
    await ctx.replyWithMediaGroup(media);
  } catch (error) {
    console.error('Không gửi được nhóm ảnh:', error.message);
  }
}

bot.start(async ctx => {
  await showMainMenu(ctx);
});

bot.command('menu', async ctx => {
  await showMainMenu(ctx);
});

bot.command('help', async ctx => {
  await showMainMenu(ctx);
});

bot.action(CALLBACK.MAIN_MENU, async ctx => {
  await safeAnswerCbQuery(ctx);
  await showMainMenu(ctx, true);
});

bot.action(CALLBACK.LOGIN_ERROR, async ctx => {
  await safeAnswerCbQuery(ctx);
  await ctx.reply(loginErrorText, {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    ...backButton()
  });
});

bot.action(CALLBACK.RESOURCE_ERROR, async ctx => {
  await safeAnswerCbQuery(ctx);
  await ctx.reply(resourceErrorText, {
    parse_mode: 'HTML',
    ...contactButtons()
  });
});

bot.action(CALLBACK.INSTALL_GUIDE, async ctx => {
  await safeAnswerCbQuery(ctx);

  const text = installGuideText();

  // Telegram giới hạn mỗi tin nhắn khoảng 4096 ký tự.
  if (text.length <= 3900) {
    await ctx.reply(text, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...backButton()
    });
    return;
  }

  const splitAt = text.indexOf('🔗 <b>Link 6:</b>');
  const part1 = splitAt > 0 ? text.slice(0, splitAt).trim() : text.slice(0, 3800);
  const part2 = splitAt > 0 ? text.slice(splitAt).trim() : text.slice(3800);

  await ctx.reply(part1, {
    parse_mode: 'HTML',
    disable_web_page_preview: true
  });

  await ctx.reply(part2, {
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    ...backButton()
  });
});

bot.action(CALLBACK.TRUST_ERROR, async ctx => {
  await safeAnswerCbQuery(ctx);
  await ctx.reply(trustedDeveloperText, {
    parse_mode: 'HTML'
  });

  await sendTrustedDeveloperImages(ctx);

  await ctx.reply('Bạn có thể xem lại menu hoặc liên hệ để được hỗ trợ thêm.', {
    ...contactButtons()
  });
});

bot.action(CALLBACK.VIP_PRICE, async ctx => {
  await safeAnswerCbQuery(ctx);
  await ctx.reply(vipPriceText, {
    parse_mode: 'HTML',
    ...contactButtons()
  });
});

bot.action(CALLBACK.CONTACT, async ctx => {
  await safeAnswerCbQuery(ctx);
  await ctx.reply(
    '💬 <b>LIÊN HỆ HỖ TRỢ</b>\n\nChọn đúng người bạn cần liên hệ:',
    {
      parse_mode: 'HTML',
      ...contactButtons()
    }
  );
});

bot.on('text', async ctx => {
  await ctx.reply(
    'Mình chưa hiểu nội dung này. Vui lòng chọn một mục trong menu bên dưới.',
    mainMenu()
  );
});

bot.catch((error, ctx) => {
  console.error(`Bot gặp lỗi ở update ${ctx.update?.update_id}:`, error);
});

async function startBot() {
  await bot.telegram.setMyCommands([
    { command: 'start', description: 'Khởi động bot' },
    { command: 'menu', description: 'Mở menu hỗ trợ' },
    { command: 'help', description: 'Hiển thị trợ giúp' }
  ]);

  await bot.launch();
  console.log('Bot TFT PBE đang chạy...');
}

startBot().catch(error => {
  console.error('Không thể khởi động bot:', error);
  process.exit(1);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
